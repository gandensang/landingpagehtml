<!DOCTYPE html>
<html lang="en">
<?php include 'header.php' ?>
<body>
    <img class="lpimage" src="img/obrok-1.png"/>
    <a href="#pemesanan"><img class="lpimage" src="img/obrok-2.png"/></a>
    <img class="lpimage" src="img/obrok-3.png"/>
    <img class="lpimage" src="img/obrok-4.png"/>
    <img class="lpimage" src="img/obrok-5.png" id="pemesanan"/>
    <img class="lpimage" src="img/obrok-6.png"/>
    <div class="mt-20">
        <?php include 'formorder.php' ?>
    </div>
    <?php include 'about.php' ?>
    <?php include 'feature.php' ?>
    <?php include 'footer.php' ?>
</body>
</html>