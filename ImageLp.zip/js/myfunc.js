function scrollToPemesanan() {
    var element = document.getElementById("pemesanan");
    element.scrollIntoView({ behavior: "smooth" });
}